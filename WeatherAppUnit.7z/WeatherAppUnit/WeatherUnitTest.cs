﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Net;
using Newtonsoft.Json;

namespace WeatherAppUnit
{
    [TestClass]
    public class WeatherUnitTest
    {
        //
        //Test for Case user does not select Wind's speed
        //
        [TestMethod]
        public void EmptyWindMph()
        {
            string city = "london";
            WebClient client = new WebClient();
            string cels = "http://localhost:60350/Weather/get?location=" + city;
            var result1 = JsonConvert.DeserializeObject<ApiModel>(client.DownloadString(cels));
            Assert.AreEqual(result1.windSpeedMph, 0);
        }

        //
        //Test for Case user does not select Wind's speed
        //
        [TestMethod]
        public void EmptyWindKph()
        {
            WebClient client = new WebClient();
            string fahrn = "http://localhost:60368/Weather";
            var result2 = JsonConvert.DeserializeObject<ApiModel>(client.DownloadString(fahrn));
            Assert.AreEqual(result2.windSpeedKph, 0);
        }

        //
        //Test for Case user does not select Celsius Temperature
        //
        [TestMethod]
        public void EmptyTempCel()
        {
            string city = "london";
            WebClient client = new WebClient();
            string cels = "http://localhost:60350/Weather/get?location=" + city;
            var result1 = JsonConvert.DeserializeObject<ApiModel>(client.DownloadString(cels));
            Assert.AreEqual(result1.temperatureFahrenheit, 0);
        }

        //
        //Test for Case user does not select Fahreneit Temperature
        //
        [TestMethod]
        public void EmptyWindFer()
        {
            WebClient client = new WebClient();
            string fahrn = "http://localhost:60368/Weather";
            var result2 = JsonConvert.DeserializeObject<ApiModel>(client.DownloadString(fahrn));
            Assert.AreEqual(result2.temperatureCelsius, 0);
        }
    }
}
