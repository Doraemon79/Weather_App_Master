﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WeatherAppUnit
{
    public class ApiModel
    {
        public double temperatureFahrenheit { get; set; }
        public string where { get; set; }
        public double windSpeedMph { get; set; }

        public double temperatureCelsius { get; set; }
        public string location { get; set; }
        public double windSpeedKph { get; set; }
    }
}